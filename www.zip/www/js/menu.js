 menu = {
 create:function(){
 			bg = game.add.image(0,0, "bg");
 			bg.scale.x = 1.60;
 			bg.scale.y = 1.75;
			var buttonPlay = game.add.button(313,300,'button1',process.startGame, this, 1,0);
			buttonPlay.scale.x = 1.4;
 			buttonPlay.scale.y = 1.7;
            
 	lines = game.add.group();
    lines.enableBody = true; 
    line = lines.create(50, 600, 'line');
    line.body.immovable = true;		  
	birds = game.add.group();
    birds.enableBody = true; 
   bird = birds.create(650, 450, 'bird');
    bird.body.immovable = true;
    bird.scale.x = 2;
    bird.scale.y = 1.5;

      
        rats = game.add.group();
    	rats.enableBody = true; 

         for (var d = 0; d < 16; d++)
        {
            var rat = rats.create(d * 100, 0, 'rat');
            rat.body.gravity.y =300;
          
            rat.body.bounce.y = .5;
        }

 	},

 	update:function(){
            game.physics.arcade.collide(rats, lines);

 	}
    };