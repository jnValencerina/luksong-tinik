process = {
    startGame: function(){
        game.state.start('play');
        console.log("this");
    },
     killF:function (player,bird){
        bgSound.play();
       
       if(process.getData()<=Scores) {
        process.saveData(Scores);
      BestText = "Best: ";
        console.log("x");

    }
    else{
        console.log("a");
    }   
     game.state.start("menu");
bgAudio.stop();
    game._paused = true;
    gameOverText.text = "GAME OVER!!!\nTap to Restart\nHigh Score: "+process.getData()+"\nScores: "+Scores;

    },
killRat:function (player,tinik){
        bgSound.play();
       
       if(process.getData()<=Scores) {
        process.saveData(Scores);
      process.BestText = "Best: ";
        console.log("x");

    }
    else{
        console.log("e");
    }
    game.state.start("menu");
    bgAudio.stop();
    game._paused = true;
    gameOverText.text = "GAME OVER!!!\nTap to Restart\nHigh Score: "+process.getData()+"\nScores: "+Scores;

    },

    killTin:function (player,tin){
        bgSound.play();
       
      if(process.getData()<=Scores) {
        process.saveData(Scores);
       process.BestText = "Best: ";
        console.log("x");

    }
    else{
        console.log("b");
    }
    game.state.start("menu");
    bgAudio.stop();
    game._paused = true;
    gameOverText.text = "GAME OVER!!!\nTap to Restart\nHigh Score: "+process.getData()+"\nScores: "+Scores;

    },
    killBall:function (player,tinikk){
        bgSound.play();
       
        if(process.getData()<=Scores) {
        process.saveData(Scores);
       process.BestText = "Best: ";
        console.log("x");

    }
    else{
        console.log("h");
    } 
    game.state.start("menu");
    bgAudio.stop();
    gameOverText.text = "GAME OVER!!!\nTap to Restart\nHigh Score: "+process.getData()+"\nScores: "+Scores;
     game._paused = true;

    },
    collectcoin:function (player, coin) {
    Scores += 1; 
    coin.kill();
    if(process.getData()<=Scores) {
      process.saveData(Scores);
       process.BestText = "Best: "+Scores;
        console.log("x");
    }
    else{
        console.log("x");
    }
 

   scoreText.text = 'Scores: ' + Scores;
   bestText.text ='Best:' +process.getData();

   
    },
     saveData:function(Scores){
    localStorage.setItem("gameData",Scores);
    },

     getData:function(){
    return (localStorage.getItem("gameData") == null || localStorage.getItem("gameData") == "")?0:localStorage.getItem("gameData");
    },

    btnRight:function(){  
      bgBounce.play();
        setTimeout(function(){
            right.frame = 1;
            player.animations.play('right');
            player.body.velocity.x = 100;
            player.body.velocity.y = 1600;

    
        },100);
            right.frame = 0;
              
    }
};
