    play = {
    create:function(){
      bg = game.add.image(0,0, 'fbg');

    player = game.add.sprite(0, game.world.height -10, 'rat');

    game.physics.arcade.enable(player);
    player.animations.add('left', [0,1,2], 9, true);
    player.animations.add('right', [2, 1, 0], 9, true);
    player.body.bounce.y = .25;
    player.body.gravity.y =290;
    player.body.collideWorldBounds = true;

     bgBounce=game.add.audio('bgBounce');
     bgAudio=game.add.audio('bgSound');
     bgSound=game.add.audio('pop');
            bgAudio.play();   

       birds = game.add.group();
    birds.enableBody = true; 

         for (var d = 0; d < 20; d++)
        {
            var bird = birds.create(d * 1000, 200, 'bird');
            bird.body.gravity.x = -50;
            bird.scale.x = 1.5;
            bird.scale.y =1;
        }

     tins = game.add.group();
    tins.enableBody = true; 
    tin = tins.create(1050, 440, 'tin');
    tin.body.immovable = true;
    tin = tins.create(2100, 440, 'tin');
    tin.body.immovable = true;
    tin = tins.create(3150, 440, 'tin');
    tin.body.immovable = true;
    tin = tins.create(4300, 440, 'tin');
    tin.body.immovable = true;
    tin = tins.create(5350, 440, 'tin');
    tin.body.immovable = true;
    tin = tins.create(6400, 440, 'tin');
    tin.body.immovable = true;
       tin = tins.create(7450, 440, 'tin');
    tin.body.immovable = true;
    tin = tins.create(8450, 440, 'tin');
    tin.body.immovable = true;
    tin = tins.create(9500, 440, 'tin');
    tin.body.immovable = true;
 tinikks = game.add.group();
    tinikks.enableBody = true; 
    tinikk = tinikks.create(700, 450, 'tinikk');
    tinikk.body.immovable = true;
    tinikk = tinikks.create(1750, 450, 'tinikk');
    tinikk.body.immovable = true;
    tinikk = tinikks.create(2800, 450, 'tinikk'); 
    tinikk.body.immovable = true;
    tinikk = tinikks.create(3850, 450, 'tinikk');
    tinikk.body.immovable = true;
    tinikk = tinikks.create(5000, 450, 'tinikk');
    tinikk.body.immovable = true;
    tinikk = tinikks.create(6050, 450, 'tinikk'); 
    tinikk.body.immovable = true;
    tinikk = tinikks.create(7100, 450, 'tinikk');
    tinikk.body.immovable = true;
    tinikk = tinikks.create(8150, 450, 'tinikk');
    tinikk.body.immovable = true;
    tinikk = tinikks.create(9150, 450, 'tinikk'); 
    tinikk.body.immovable = true;

    tiniks = game.add.group();
    tiniks.enableBody = true; 
    tinik = tiniks.create(350, 510, 'tinik');
    tinik.body.immovable = true;
    tinik = tiniks.create(1400, 510, 'tinik');
    tinik.body.immovable = true;
    tinik = tiniks.create(2450, 510, 'tinik');
    tinik.body.immovable = true;
    tinik = tiniks.create(3500, 510, 'tinik');
    tinik.body.immovable = true;
    tinik = tiniks.create(4650, 510, 'tinik');
    tinik.body.immovable = true;
    tinik = tiniks.create(5700, 510, 'tinik');
    tinik.body.immovable = true;
     tinik = tiniks.create(6750, 510, 'tinik');
    tinik.body.immovable = true;
    tinik = tiniks.create(7800, 510, 'tinik');
    tinik.body.immovable = true;
    tinik = tiniks.create(8800, 510, 'tinik');
    tinik.body.immovable = true;


    coins = game.add.group();
    coins.enableBody = true; 
    coin = coins.create(1050, 0, 'coin');
    coin = coins.create(2100, 0, 'coin');
    coin = coins.create(3150, 0, 'coin');
    coin = coins.create(4300, 0, 'coin');
    coin = coins.create(5350, 0, 'coin');
    coin = coins.create(6400, 0, 'coin');
    coin = coins.create(7450, 0, 'coin');
    coin = coins.create(8450, 0, 'coin');
    coin = coins.create(9500, 0, 'coin');
    coin = coins.create(700, 0, 'coin');
    coin = coins.create(1750, 0, 'coin');
    coin = coins.create(2800, 0, 'coin');
    coin = coins.create(3850, 0, 'coin');
    coin = coins.create(5000, 0, 'coin');
    coin = coins.create(6050, 0, 'coin');
    coin = coins.create(7100, 0, 'coin');
    coin = coins.create(8150, 0, 'coin');
    coin = coins.create(9150, 0, 'coin');
    coin = coins.create(350, 0, 'coin');
    coin = coins.create(1400, 0, 'coin');
    coin = coins.create(2450, 0, 'coin');
    coin = coins.create(3500, 0, 'coin');
    coin = coins.create(4650, 0, 'coin');
    coin = coins.create(5700, 0, 'coin');
    coin = coins.create(6750, 0, 'coin');
    coin = coins.create(7800, 0, 'coin');
    coin = coins.create(8800, 0, 'coin');
 

    game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);


    pause = game.add.button(745,5,"pause",process.btnpause);
    pause.fixedToCamera = true;
    right = game.add.button(700,520, 'right',process.btnRight);
    right.fixedToCamera = true;

         cursors = game.input.keyboard.createCursorKeys();

    pause.events.onInputUp.add(function () {
            pause.frame = 1;
            game.paused = true;
        });
            pause.frame = 0;
        game.input.onDown.add(unpause, self);
        function unpause(event){
        if(game.paused){
            game.paused = false;
            }
            pause.frame = 0;
        }


    scoreText = game.add.text(20,40,"Score: 0",{fill:"magenta"});
    bestText = game.add.text(20,10,"Best: "+process.getData(),{fill:"magenta"});
    gameOverText = game.add.text(300,200 ,'', {fontSize: '32px', fill: 'blue'});
    scoreText.fixedToCamera = true;
    bestText.fixedToCamera = true;
    gameOverText.fixedToCamera = true;

    },


    update:function() {
            game.physics.arcade.overlap(player, birds, process.killF,  null, this);
            game.physics.arcade.overlap(player, coins, process.collectcoin,  null, this);
            game.physics.arcade.overlap(player,tiniks, process.killRat,  null, this);
            game.physics.arcade.overlap(player,tinikks, process.killBall,  null, this);
            game.physics.arcade.overlap(player,tins, process.killTin,  null, this);
            game.physics.arcade.collide(player, birds);
            game.physics.arcade.collide(player, tiniks);
            game.physics.arcade.collide(player, tinikks);
            game.physics.arcade.collide(player, tins);

         player.body.velocity.x = 90;
    }}





