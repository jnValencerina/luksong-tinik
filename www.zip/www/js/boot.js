boot = {
create:function() {

            game.physics.startSystem(Phaser.Physics.ARCADE);
            game.world.setBounds(0,0,bounds,0);
            game.add.image(0, 0, 'black');
            cursors = game.input.keyboard.createCursorKeys();
			game.input.maxPointers = 1;
			game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
			game.scale.pageAlignHorizontally = true;
			game.scale.pageAlignVertically = true;
			game.scale.setScreenSize(true);
			game.state.start("preload");

					},
				}