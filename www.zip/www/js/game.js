var width = 800;
var height = 600;
var bounds = 10000;
var bgAudio,bgSound,bgBounce, audioLoop;
var cursors;
var scoreText, gameOverText, bestText;
var fbg, fbg3, fbg4;
var player, rat;
var tinik,tiniks, tinikks, tinikk, tin,tins, birds, bird;
var killRat;
var btnplay, play;
var btnrestart, restart, btnpause, pause, btnUp, up, btnLeft, left, btnRight;
var right,score = 0, Scores=0;
var coin, coins, bg, buttonPlay;

var game = new Phaser.Game(width, height, Phaser.CANVAS, '');

game.state.add("boot",boot);
game.state.add("preload",preload);
game.state.add("menu",menu);
game.state.add("play",play);

game.state.start("boot");