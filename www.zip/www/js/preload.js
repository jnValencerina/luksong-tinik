preload = {
preload:function() {
        game.input.maxPointers = 1;
	    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
	    game.scale.pageAlignHorizontally = true;
	    game.scale.pageAlignVertically = true;
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.setScreenSize(true);


        game.load.image('fbg', 'assets/3.png');
        game.load.image('tin', 'assets/tin.png');
        game.load.image('tinik', 'assets/tinik.png');
    	game.load.image('tinikk', 'assets/tinikk.png');
        game.load.image('coin', 'assets/coin.png');
        game.load.image('bg', 'assets/bg.png');
        game.load.image('line', 'assets/line.png');
        
    	game.load.image('bird', 'assets/bird.png');
        game.load.spritesheet('button1', 'assets/button.png', 102, 50);
        game.load.spritesheet('right', 'assets/right.png', 60, 50);
        game.load.spritesheet('pause', 'assets/pause.png', 50, 50);
    	game.load.spritesheet('rat', 'assets/rat1.png', 60, 60);
        game.load.audio("bgBounce","audio/bounce.mp3");
        game.load.audio("pop","audio/pop.mp3");
        game.load.audio("bgSound","audio/bgsound.mp3");
                    },
        create:function(){
            game.state.start("menu");
        },
};